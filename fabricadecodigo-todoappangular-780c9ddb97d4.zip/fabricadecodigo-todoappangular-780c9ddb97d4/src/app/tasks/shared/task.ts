export class Task {
    _id: string;
    description: string;
    completed: boolean;
}
